package com.example.rmesaage.utils;

public class ClingMessageExchange {

    private static final String NAMESPACE = "urn:schemas-upnp-org:service:TestService:1";
    private static final String SERVICE_NAME = "TestService";
    private static final int SERVICE_PORT = 8080;
    private static final String SERVICE_PATH = "/TestService";
    private static final String MESSAGE_TYPE = "text/plain";

    private Device device;
    private Service service;
    private Action sendMessageAction;
    private Action receiveMessageAction;

    public ClingMessageExchange(Device device) {
        this.device = device;
    }

    public void start() {
        Service service = findService(device, SERVICE_NAME);
        if (service == null) {
            throw new RuntimeException("Service not found: " + SERVICE_NAME);
        }

        sendMessageAction = findAction(service, "SendMessage");
        receiveMessageAction = findAction(service, "ReceiveMessage");

        if (sendMessageAction == null || receiveMessageAction == null) {
            throw new RuntimeException("SendMessage or ReceiveMessage action not found");
        }
    }

    public void sendMessage(String message, String targetUrl) throws Exception {
        ActionInvocation sendMessageInvocation = sendMessageAction.createInvocation();
        sendMessageInvocation.setInput("Message", message);
        sendMessageInvocation.setInput("TargetURL", targetUrl);

        UpnpService upnpService = new UpnpServiceImpl(new AndroidUpnpServiceConfiguration());
        RegistryListener registryListener = new DefaultRegistryListener() {
            @Override
            public void remoteDeviceAdded(Registry registry, RemoteDevice device) {
                if (device.getType().getNamespace().equals(NAMESPACE)) {
                    try {
                        upnpService.getControlPoint().execute(sendMessageInvocation, device.findService(service.getServiceType()));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        upnpService.getRegistry().addListener(registryListener);
        upnpService.getControlPoint().search(new ST(service.getServiceType()));
    }

    public void receiveMessages() throws Exception {
        ActionInvocation receiveMessageInvocation = receiveMessageAction.createInvocation();
        UpnpService upnpService = new UpnpServiceImpl(new AndroidUpnpServiceConfiguration());
        RegistryListener registryListener = new DefaultRegistryListener() {
            @Override
            public void remoteDeviceAdded(Registry registry, RemoteDevice device) {
                if (device.getType().getNamespace().equals(NAMESPACE)) {
                    try {
                        upnpService.getControlPoint().execute(receiveMessageInvocation, device.findService(service.getServiceType()));
                        String message = receiveMessageInvocation.getOutput("Message").getValue().toString();
                        String senderUrl = receiveMessageInvocation.getOutput("SenderURL").getValue().toString();
                        System.out.println("Received message: " + message + " from " + senderUrl);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        upnpService.getRegistry().addListener(registryListener);
        upnpService.getControlPoint().search(new ST(service.getServiceType()));
    }

    private Service findService(Device device, String serviceName) {
        for (Service service : device.getServices()) {
            if (serviceName.equals(service.getServiceId().getId())) {
                return service;
            }
        }
        return null;
    }

    private Action findAction(Service service, String actionName) {
        for (Action action : service.getActions()) {
            if (actionName.equals(action.getName())) {
                return action;
            }
        }
        return null;
    }
}
