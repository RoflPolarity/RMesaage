package com.example.rmesaage.interfaces;

import com.example.rmesaage.Chat.Message;

public interface MessageListener {
    void onMessageReceived(Message message);
}
